﻿module BankAccountI
open System

type AccountUpdate = 
    | BalanceChange of decimal
    | Open of bool

type Message = 
        | Query of AsyncReplyChannel<Reply>
        | Update of AccountUpdate*AsyncReplyChannel<Reply>
and Reply = 
            | Failure of string
            | Info of decimal option
            | Notify of string

type BankAccount() = 
    let mutable balance:decimal option = None
    let mailbox = // http://msdn.microsoft.com/en-us/library/ee370357.aspx
        let bankMaker = new MailboxProcessor<Message>(fun inbox ->
            let rec Loop() = 
                async{
                    let! message = inbox.Receive()
                    match message with 
                    | Query replyChannel -> 
                        replyChannel.Reply(Info(balance))
                    | (Update(AccountUpdate.BalanceChange(changeAmount),replyChannel)) ->
                        match balance with
                        | Some x -> balance <- Some (balance.Value + changeAmount); replyChannel.Reply(Reply.Info(balance))
                        | None -> replyChannel.Reply <| Failure "Account is not open"
                    | (Update( AccountUpdate.Open (doOpen), replyChannel)) ->
                        match balance.IsSome,doOpen with
                        | true,true -> balance <- Some 0.0m; replyChannel.Reply(Failure("Could not open already opened account"))
                        | false,false -> replyChannel.Reply(Failure("Could not close already closed account"))
                        | true,false -> // close account
                            let previousBalance = balance.Value
                            balance <- None
                            replyChannel.Reply(Info(Some previousBalance))
                        | false,true -> // open account
                            balance <- Some 0.0m
                            replyChannel.Reply(Info(balance))
                    do! Loop()
                    }
            Loop())
        bankMaker.Start()
        bankMaker
    let tryGetBalance() = 
        match mailbox.PostAndReply(fun replyChannel -> Query replyChannel) with
        |Info balance -> balance
        |_ -> raise(InvalidOperationException("Reply does not make sense"))
    let tryOpenOrClose changeType doOpen = 
        match mailbox.PostAndReply( fun replyChannel -> Update(Open(doOpen),replyChannel)) with // balance <- Some 0.0m
                                    | Notify s -> s
                                    | Failure s -> s// raise(InvalidOperationException(sprintf "account could not be %s:%s" changeType s))
                                    | Info balance -> sprintf "Account %s with a balance of %M" changeType balance.Value
                                    //| _ -> raise(InvalidOperationException("Reply does not make sense"))
    member this.openAccount() = tryOpenOrClose "opened" true |> ignore<string>
    member this.getBalance() = tryGetBalance().Value //balance.Value
    member this.updateBalance changeAmount = 
        // balance <- if balance.IsSome then Some( balance.Value + value) else raise(InvalidOperationException("account is closed"))
        match mailbox.PostAndReply(fun replyChannel -> Update(AccountUpdate.BalanceChange(changeAmount),replyChannel)) with
        | Info balance -> printfn "New balance is %M" balance.Value; ()
        | _ -> raise(InvalidOperationException("Reply does not make sense"))
    member this.Balance = tryGetBalance()
    member this.closeAccount() = 
        tryOpenOrClose "closed" false
        |> printfn "%s"

let mkBankAccount() =  BankAccount()
let openAccount (account:BankAccount) = 
    account.openAccount()
    account

let closeAccount (account:BankAccount) = 
    account.closeAccount()
    account

let getBalance  (account:BankAccount) = account.getBalance ()
let updateBalance change (account:BankAccount) = 
    account.updateBalance change
    account
