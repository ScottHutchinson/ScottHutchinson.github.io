﻿module BankAccount7

type Account = { Balance: decimal option }

type Task =
    | Open of account: Account * replyChannel: AsyncReplyChannel<Account>
    | Close of account: Account * replyChannel: AsyncReplyChannel<Account>
    | UpdateBalance of account: Account * change: decimal * replyChannel: AsyncReplyChannel<Account>

let addBalance (balance: decimal option) change =
    match balance with
    | Some b -> Some(b + change)
    | None -> None

let processor = MailboxProcessor<Task>.Start(fun inbox ->
    let rec innerLoop () = async {
        let! message = inbox.Receive()
        match message with
        | Open (account, replyChannel) ->
            let account = { account with Balance = Some 0.0m }
            replyChannel.Reply(account)
        | Close (account, replyChannel) ->
            let account = { account with Balance = None }
            replyChannel.Reply(account)
        | UpdateBalance (account, change, replyChannel) ->
            let account = { account with Balance = (addBalance account.Balance change) }
            replyChannel.Reply(account)
        do! innerLoop ()
    }
    innerLoop ())

let mkBankAccount () = { Balance = None }

let openAccount account =
    processor.PostAndReply (fun replyChannel -> Open (account, replyChannel))

let closeAccount account =
    processor.PostAndReply (fun replyChannel -> Close (account, replyChannel))

let getBalance account = account.Balance

let updateBalance change account =
    processor.PostAndReply (fun replyChannel -> UpdateBalance (account, change, replyChannel))
