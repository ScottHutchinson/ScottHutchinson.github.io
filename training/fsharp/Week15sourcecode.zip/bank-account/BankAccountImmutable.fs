﻿// Some tests are not designed to work with an immutable data structure.

module BankAccountImmutable

type Account = { IsOpen: bool; Transactions: decimal list }

let mkBankAccount() =  { IsOpen = false; Transactions = [] }

let openAccount account =
    { IsOpen = true; Transactions = 0.0m :: account.Transactions }
    // openedAcct

let closeAccount account = { account with IsOpen = false }

let getBalance account = 
    match account.IsOpen with
    | true -> account.Transactions |> Seq.sum |> Some
    | false -> None

let updateBalance change account =
    match account.IsOpen with
    | true -> { account with Transactions = change :: account.Transactions }
    | false -> failwith "ERROR: Cannot update the balance for a closed account."
    // account
