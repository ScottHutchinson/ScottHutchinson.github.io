﻿module BankAccount

open System.Collections.Concurrent

type Account = { IsOpen: bool; Transactions: ConcurrentQueue<decimal> }

let mkBankAccount() =  { IsOpen = false; Transactions = ConcurrentQueue<decimal>() }

let openAccount account =
    let openedAcct = { account with IsOpen = true }
    openedAcct.Transactions.Enqueue 0.0m
    openedAcct

let closeAccount account = { account with IsOpen = false }

let getBalance account = 
    match account.IsOpen with
    | true -> account.Transactions |> Seq.sum |> Some
    | false -> None

let updateBalance change account =
    match account.IsOpen with
    | true -> account.Transactions.Enqueue change
    | false -> failwith "ERROR: Cannot update the balance for a closed account."
    account
